import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Read the Picovoice access key from local.properties (never commit it).
// local.properties -> PICOVOICE_ACCESS_KEY=xxxxxxxx
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val picovoiceAccessKey: String = localProps.getProperty("PICOVOICE_ACCESS_KEY") ?: ""

android {
    namespace = "com.angel.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.angel.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    defaultConfig {
        buildConfigField("String", "PICOVOICE_ACCESS_KEY", "\"$picovoiceAccessKey\"")
    }
    // Vosk ships a bundled JNA; avoid duplicate native/meta files at packaging.
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/INDEX.LIST"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.localbroadcastmanager:localbroadcastmanager:1.1.0")

    // Offline wake-word detection.
    // Porcupine: primary detector (requires an access key + a custom "Angel" .ppn).
    implementation("ai.picovoice:porcupine-android:3.0.2")
    // Vosk: fallback keyword-spotting engine (requires an unpacked model in assets).
    implementation("com.alphacephei:vosk-android:0.3.47")
}
