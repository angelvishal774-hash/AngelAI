Angel AI — Offline Wake-Word Assets
===================================

The app runs out of the box WITHOUT any of these files: it falls back to
SpeechRecognizer-based wake detection. Add either set below to upgrade to true
low-power offline wake-word detection. WakeWordFactory picks the best available.

------------------------------------------------------------------
Option 1 (recommended): Porcupine — "Angel" custom keyword
------------------------------------------------------------------
1. Go to https://console.picovoice.ai and create a free account.
2. Copy your AccessKey.
3. In the "Porcupine" section, train a custom wake word "Angel" for the
   Android platform. Download the generated file.
4. Rename it to:            Angel_en_android.ppn
   and place it in:         app/src/main/assets/Angel_en_android.ppn
5. Put your key in project-root local.properties (do NOT commit it):
        PICOVOICE_ACCESS_KEY=your_access_key_here

(The Gradle build reads that value into BuildConfig.PICOVOICE_ACCESS_KEY.)

------------------------------------------------------------------
Option 2: Vosk — offline keyword spotting (no access key)
------------------------------------------------------------------
1. Download a small English model, e.g.
   "vosk-model-small-en-in-0.4" from https://alphacephei.com/vosk/models
2. Unzip it into:
        app/src/main/assets/vosk-model-small-en-in-0.4/
   (the folder should directly contain am/, conf/, graph/, ivector/, etc.)
3. If you use a different folder name, update
   WakeWordFactory.VOSK_MODEL_DIR to match.

------------------------------------------------------------------
Notes
------------------------------------------------------------------
- Only one component uses the mic at a time: the wake engine while SLEEPING,
  Android SpeechRecognizer while AWAKE. The service swaps them automatically.
- Vosk models are large (40 MB+); they inflate the APK. Porcupine .ppn files
  are tiny (a few KB) and more battery-efficient — prefer Option 1.
