package com.angel.ai.wake

import android.content.Context
import android.util.Log
import ai.picovoice.porcupine.PorcupineManager

/**
 * Primary offline wake-word engine, powered by Picovoice Porcupine.
 *
 * [PorcupineManager] owns its own audio thread, so we never touch AudioRecord
 * directly. Detection is fully offline and low-power. Because "Angel" is not a
 * built-in keyword, a custom `.ppn` model (trained at console.picovoice.ai) must
 * be placed in `app/src/main/assets/` and an access key supplied via
 * local.properties (see [com.angel.ai.wake.WakeWordFactory]).
 */
class PorcupineWakeWordEngine(
    private val context: Context,
    private val accessKey: String,
    private val keywordAssetPath: String,
    private val sensitivity: Float,
    private val onWake: () -> Unit
) : WakeWordEngine {

    override val id = "porcupine"
    override val ownsMicrophone = true

    private var manager: PorcupineManager? = null

    override fun start() {
        if (manager != null) return
        try {
            manager = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeywordPath(keywordAssetPath)
                .setSensitivity(sensitivity)
                .build(context) { /* keywordIndex */ onWake() }
            manager?.start()
            Log.i(TAG, "Porcupine listening for wake word ($keywordAssetPath)")
        } catch (t: Throwable) {
            // Bad key, missing/invalid .ppn, or unsupported ABI. Let the factory
            // fall through to Vosk / SpeechRecognizer.
            Log.e(TAG, "Porcupine failed to start", t)
            safeRelease()
            throw t
        }
    }

    override fun stop() = safeRelease()

    private fun safeRelease() {
        runCatching { manager?.stop() }
        runCatching { manager?.delete() }
        manager = null
    }

    companion object {
        private const val TAG = "AngelPorcupine"
    }
}
