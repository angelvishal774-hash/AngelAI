package com.angel.ai.speech

import java.util.Locale

/** The three languages Angel understands and replies in. */
enum class Lang(val locale: Locale) {
    MARATHI(Locale("mr", "IN")),
    HINDI(Locale("hi", "IN")),
    ENGLISH(Locale.ENGLISH)
}

/**
 * Best-effort language detector.
 *
 * Marathi and Hindi share the Devanagari script, so script alone can't separate
 * them. We use two cues: (1) Marathi-only letters like ळ / ऱ, and (2) a small
 * set of high-frequency distinctive words. Latin text is treated as English.
 * Ambiguous Devanagari defaults to Marathi since Angel is Marathi-first.
 */
object LanguageDetector {

    private val devanagari = Regex("[\\u0900-\\u097F]")
    private val marathiOnlyChars = Regex("[ळऱ]")

    private val marathiHints = listOf(
        "आहे", "आहेस", "आहात", "कसा", "कशी", "कसे", "काय", "तू", "तुम्ही",
        "नको", "नाही", "धन्यवाद", "नमस्कार", "किती", "वाजले", "आभार", "बरं",
        "मला", "माझं", "माझा", "करून", "वेळ", "तारीख", "वार"
    )
    private val hindiHints = listOf(
        "है", "हैं", "हो", "कैसे", "क्या", "आप", "नहीं", "धन्यवाद", "नमस्ते",
        "कितने", "बजे", "मुझे", "मेरा", "कीजिये", "करो", "समय", "तारीख", "दिन"
    )

    fun detect(text: String): Lang {
        if (!devanagari.containsMatchIn(text)) return Lang.ENGLISH
        if (marathiOnlyChars.containsMatchIn(text)) return Lang.MARATHI

        val m = marathiHints.count { text.contains(it) }
        val h = hindiHints.count { text.contains(it) }
        return when {
            m > h -> Lang.MARATHI
            h > m -> Lang.HINDI
            else -> Lang.MARATHI
        }
    }
}
