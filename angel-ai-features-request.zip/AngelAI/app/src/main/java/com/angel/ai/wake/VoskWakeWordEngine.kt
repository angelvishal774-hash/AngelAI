package com.angel.ai.wake

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * Fallback offline wake-word engine, powered by Vosk.
 *
 * Unlike Porcupine, Vosk needs no access key — only a model directory unpacked
 * from assets (e.g. `vosk-model-small-en-in-0.4`). We constrain the recognizer
 * with a tiny grammar so it only has to spot the single word "angel", which
 * keeps CPU/battery use low while sleeping.
 */
class VoskWakeWordEngine(
    private val context: Context,
    private val modelAssetDir: String,
    private val onWake: () -> Unit
) : WakeWordEngine, RecognitionListener {

    override val id = "vosk"
    override val ownsMicrophone = true

    private var model: Model? = null
    private var speechService: SpeechService? = null
    @Volatile private var running = false

    override fun start() {
        if (running) return
        running = true
        // Unpacking copies the model out of assets on first run; it's async.
        StorageService.unpack(
            context, modelAssetDir, "vosk-model",
            { unpacked ->
                model = unpacked
                beginRecognition()
            },
            { e -> Log.e(TAG, "Vosk model unpack failed", e); running = false }
        )
    }

    private fun beginRecognition() {
        val m = model ?: return
        try {
            val grammar = "[\"angel\", \"[unk]\"]"
            val recognizer = Recognizer(m, SAMPLE_RATE, grammar)
            speechService = SpeechService(recognizer, SAMPLE_RATE)
            speechService?.startListening(this)
            Log.i(TAG, "Vosk listening for wake word")
        } catch (t: Throwable) {
            Log.e(TAG, "Vosk failed to start recognition", t)
            running = false
        }
    }

    override fun stop() {
        running = false
        runCatching { speechService?.stop() }
        runCatching { speechService?.shutdown() }
        speechService = null
        runCatching { model?.close() }
        model = null
    }

    private fun matched(json: String?) {
        if (json.isNullOrBlank()) return
        val heard = runCatching {
            val obj = JSONObject(json)
            (obj.optString("text") + " " + obj.optString("partial")).trim()
        }.getOrDefault(json)
        if (heard.contains("angel", ignoreCase = true)) onWake()
    }

    override fun onPartialResult(hypothesis: String?) = matched(hypothesis)
    override fun onResult(hypothesis: String?) = matched(hypothesis)
    override fun onFinalResult(hypothesis: String?) = matched(hypothesis)
    override fun onError(e: Exception?) {
        Log.e(TAG, "Vosk error", e)
    }
    override fun onTimeout() {}

    companion object {
        private const val TAG = "AngelVosk"
        private const val SAMPLE_RATE = 16000.0f
    }
}
