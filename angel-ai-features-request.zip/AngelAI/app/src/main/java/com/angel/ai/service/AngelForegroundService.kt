package com.angel.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.angel.ai.MainActivity
import com.angel.ai.R
import com.angel.ai.speech.AngelIntent
import com.angel.ai.speech.CommandBuffer
import com.angel.ai.speech.CommandParser
import com.angel.ai.speech.LanguageDetector
import com.angel.ai.speech.ReplyEngine
import com.angel.ai.speech.SpeechManager
import com.angel.ai.speech.TtsManager
import com.angel.ai.wake.WakeWordEngine
import com.angel.ai.wake.WakeWordFactory
import java.util.Locale

/**
 * The always-on brain. Runs as a foreground service (type=microphone) so Angel
 * keeps listening while the app is backgrounded.
 *
 * State machine:
 *   SLEEPING  -> only the wake word ("Angel") is acted on.
 *   AWAKE     -> command buffer is fresh; commands are executed until a SLEEP
 *                command or the awake window times out.
 */
class AngelForegroundService : LifecycleService() {

    enum class State { SLEEPING, AWAKE }

    private lateinit var speech: SpeechManager
    private lateinit var tts: TtsManager
    private lateinit var wake: WakeWordEngine
    private val buffer = CommandBuffer()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var state = State.SLEEPING
    private var awakeTimeout: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        tts = TtsManager(this)
        speech = SpeechManager(this, ::onSpeech, ::onSpeechError)
        // Offline wake-word engine (Porcupine > Vosk > SpeechRecognizer fallback).
        wake = WakeWordFactory.create(this) {
            // Detector callbacks arrive off the main thread; hop back before
            // touching state or creating a SpeechRecognizer.
            main.post { onWakeWordDetected() }
        }
        registerControlReceiver()
        startAsForeground()
        enterSleepListening()
        broadcastState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_WAKE -> wake()
            ACTION_SLEEP -> sleep(spoken = true)
            ACTION_STOP_SERVICE -> stopSelf()
        }
        return START_STICKY
    }

    // ---- Speech handling -------------------------------------------------

    private fun onSpeech(text: String, isFinal: Boolean) {
        if (text.isBlank()) return

        if (state == State.SLEEPING) {
            // Reached only when the SpeechRecognizer fallback owns the mic while
            // sleeping. Offline engines (Porcupine/Vosk) call onWakeWordDetected
            // directly. Trigger on partials so it fires the instant it's heard.
            if (CommandParser.containsWake(text)) onWakeWordDetected()
            return
        }

        // AWAKE: act only on finalized phrases to avoid double-firing.
        if (!isFinal) return
        buffer.push(text)
        val cmd = CommandParser.parse(text)
        val lang = LanguageDetector.detect(text)
        Log.i(TAG, "Command: ${cmd.intent} [$lang] <- \"${cmd.raw}\"")
        when (cmd.intent) {
            AngelIntent.SLEEP -> sleep(spoken = true)
            AngelIntent.GOODBYE -> {
                val r = ReplyEngine.reply(cmd.intent, lang, text)
                respond(r.text, r.lang.locale)
                sleep(spoken = false)
                return
            }
            AngelIntent.READ_MESSAGES -> respond(lastMessage ?: getString(R.string.no_messages))
            AngelIntent.CALL_INFO -> respond(lastCall ?: getString(R.string.no_calls))
            AngelIntent.CONFIRM_YES -> forwardConfirm(true)
            AngelIntent.CONFIRM_NO -> forwardConfirm(false)
            AngelIntent.WAKE -> respond(getString(R.string.listening))
            // Conversational intents are answered in the detected language.
            AngelIntent.GREETING,
            AngelIntent.HOW_ARE_YOU,
            AngelIntent.IDENTITY,
            AngelIntent.TIME,
            AngelIntent.DATE,
            AngelIntent.DAY,
            AngelIntent.THANKS,
            AngelIntent.HELP,
            AngelIntent.UNKNOWN -> {
                val r = ReplyEngine.reply(cmd.intent, lang, text)
                respond(r.text, r.lang.locale)
            }
        }
        // Any command refreshes the awake window.
        scheduleSleep()
    }

    private fun onSpeechError(code: Int) {
        Log.w(TAG, "Speech error $code")
    }

    /** Fired by the offline wake engine or the SpeechRecognizer fallback. */
    private fun onWakeWordDetected() = wake()

    // ---- Microphone coordination ----------------------------------------
    // Only one component may capture the mic at a time. While SLEEPING the wake
    // engine owns it; while AWAKE the SpeechRecognizer owns it.

    private fun enterSleepListening() {
        if (wake.ownsMicrophone) {
            speech.stop()
            wake.start()
        } else {
            wake.stop()
            speech.start() // fallback: SpeechRecognizer listens for the wake word
        }
    }

    private fun enterAwakeListening() {
        wake.stop()
        speech.start()
    }

    // ---- Wake / Sleep ----------------------------------------------------

    private fun wake() {
        if (state == State.AWAKE) return
        state = State.AWAKE
        buffer.reset() // fresh command buffer every wake
        enterAwakeListening() // hand the mic to SpeechRecognizer
        respond(getString(R.string.yes_im_listening))
        updateNotification()
        broadcastState()
        scheduleSleep()
    }

    private fun sleep(spoken: Boolean) {
        awakeTimeout?.let { main.removeCallbacks(it) }
        if (state == State.SLEEPING) return
        state = State.SLEEPING
        buffer.reset()
        if (spoken) respond(getString(R.string.going_to_sleep))
        enterSleepListening() // hand the mic back to the wake engine
        updateNotification()
        broadcastState()
    }

    private fun scheduleSleep() {
        awakeTimeout?.let { main.removeCallbacks(it) }
        val r = Runnable { sleep(spoken = false) }
        awakeTimeout = r
        main.postDelayed(r, AWAKE_WINDOW_MS)
    }

    private fun respond(text: String, locale: Locale? = null) {
        tts.speak(text, locale)
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(EVENT_TRANSCRIPT).putExtra(EXTRA_TEXT, text)
        )
    }

    // ---- UPI confirm relay ------------------------------------------------

    private fun forwardConfirm(approved: Boolean) {
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(EVENT_UPI_DECISION).putExtra(EXTRA_APPROVED, approved)
        )
        respond(if (approved) getString(R.string.payment_approved) else getString(R.string.payment_blocked))
    }

    // ---- Notification data fed in from the NotificationListener ----------

    private fun registerControlReceiver() {
        val filter = IntentFilter().apply {
            addAction(EVENT_CALL)
            addAction(EVENT_MESSAGE)
            addAction(EVENT_UPI_DETECTED)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(controlReceiver, filter)
    }

    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                EVENT_CALL -> {
                    lastCall = intent.getStringExtra(EXTRA_TEXT)
                    respond(getString(R.string.incoming_call, lastCall ?: "?"))
                }
                EVENT_MESSAGE -> {
                    lastMessage = intent.getStringExtra(EXTRA_TEXT)
                    respond(getString(R.string.new_message, lastMessage ?: ""))
                }
                EVENT_UPI_DETECTED -> {
                    // Payment screen detected -> wake so the user can say yes/no.
                    val payee = intent.getStringExtra(EXTRA_TEXT) ?: "?"
                    wake()
                    respond(getString(R.string.confirm_payment, payee))
                }
            }
        }
    }

    private var lastCall: String? = null
    private var lastMessage: String? = null

    // ---- Foreground notification -----------------------------------------

    private fun startAsForeground() {
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val toggleAction = if (state == State.AWAKE) {
            NotificationCompat.Action(
                0, getString(R.string.sleep),
                servicePending(ACTION_SLEEP, 1)
            )
        } else {
            NotificationCompat.Action(
                0, getString(R.string.wake),
                servicePending(ACTION_WAKE, 2)
            )
        }
        val statusText = if (state == State.AWAKE) getString(R.string.status_awake)
        else getString(R.string.status_sleeping)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_angel)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(toggleAction)
            .addAction(
                NotificationCompat.Action(
                    0, getString(R.string.stop),
                    servicePending(ACTION_STOP_SERVICE, 3)
                )
            )
            .build()
    }

    private fun servicePending(action: String, req: Int): PendingIntent {
        val i = Intent(this, AngelForegroundService::class.java).setAction(action)
        return PendingIntent.getService(
            this, req, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.channel_desc) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun broadcastState() {
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(EVENT_STATE).putExtra(EXTRA_STATE, state.name)
        )
    }

    override fun onDestroy() {
        awakeTimeout?.let { main.removeCallbacks(it) }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(controlReceiver)
        wake.stop()
        speech.stop()
        tts.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AngelService"
        private const val CHANNEL_ID = "angel_ai_core"
        private const val NOTIF_ID = 1001
        private const val AWAKE_WINDOW_MS = 12_000L

        const val ACTION_WAKE = "com.angel.ai.WAKE"
        const val ACTION_SLEEP = "com.angel.ai.SLEEP"
        const val ACTION_STOP_SERVICE = "com.angel.ai.STOP"

        // LocalBroadcast events
        const val EVENT_STATE = "com.angel.ai.EVENT_STATE"
        const val EVENT_TRANSCRIPT = "com.angel.ai.EVENT_TRANSCRIPT"
        const val EVENT_CALL = "com.angel.ai.EVENT_CALL"
        const val EVENT_MESSAGE = "com.angel.ai.EVENT_MESSAGE"
        const val EVENT_UPI_DETECTED = "com.angel.ai.EVENT_UPI_DETECTED"
        const val EVENT_UPI_DECISION = "com.angel.ai.EVENT_UPI_DECISION"

        const val EXTRA_TEXT = "text"
        const val EXTRA_STATE = "state"
        const val EXTRA_APPROVED = "approved"

        fun start(context: Context) {
            val i = Intent(context, AngelForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }
    }
}
