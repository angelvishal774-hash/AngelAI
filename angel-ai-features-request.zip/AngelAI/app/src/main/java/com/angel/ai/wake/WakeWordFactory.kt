package com.angel.ai.wake

import android.content.Context
import android.content.res.AssetManager
import android.util.Log
import com.angel.ai.BuildConfig

/**
 * Picks the best available offline wake-word engine at runtime:
 *
 *   1. Porcupine  — if an access key is configured AND the custom "Angel" .ppn
 *                   keyword file is present in assets.
 *   2. Vosk       — if a Vosk model directory is present in assets.
 *   3. NoOp       — nothing bundled; the service falls back to SpeechRecognizer
 *                   wake detection (works everywhere, just less battery-friendly).
 *
 * This keeps the app compilable and runnable with zero setup, while upgrading
 * automatically to true offline wake-word detection once the assets are added.
 */
object WakeWordFactory {

    private const val TAG = "AngelWake"

    /** Custom keyword file — place in app/src/main/assets/. */
    const val PORCUPINE_KEYWORD_ASSET = "Angel_en_android.ppn"

    /** Vosk model directory — unzip a model into app/src/main/assets/<this>. */
    const val VOSK_MODEL_DIR = "vosk-model-small-en-in-0.4"

    fun create(context: Context, onWake: () -> Unit): WakeWordEngine {
        val assets = context.assets
        val key = BuildConfig.PICOVOICE_ACCESS_KEY

        if (key.isNotBlank() && assetExists(assets, PORCUPINE_KEYWORD_ASSET)) {
            runCatching {
                val engine = PorcupineWakeWordEngine(
                    context, key, PORCUPINE_KEYWORD_ASSET, sensitivity = 0.6f, onWake = onWake
                )
                Log.i(TAG, "Using Porcupine wake engine")
                return engine
            }.onFailure { Log.w(TAG, "Porcupine unavailable, trying next", it) }
        }

        if (assetDirExists(assets, VOSK_MODEL_DIR)) {
            Log.i(TAG, "Using Vosk wake engine")
            return VoskWakeWordEngine(context, VOSK_MODEL_DIR, onWake)
        }

        Log.i(TAG, "No offline wake assets found; using SpeechRecognizer fallback")
        return NoOpWakeWordEngine()
    }

    private fun assetExists(am: AssetManager, path: String): Boolean =
        runCatching { am.open(path).close(); true }.getOrDefault(false)

    private fun assetDirExists(am: AssetManager, dir: String): Boolean =
        runCatching { am.list(dir)?.isNotEmpty() == true }.getOrDefault(false)
}
