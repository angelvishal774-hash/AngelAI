package com.angel.ai.speech

import java.text.SimpleDateFormat
import java.util.Date

/** A response plus the locale it should be spoken in. */
data class Reply(val text: String, val lang: Lang)

/**
 * Trilingual conversational response generator.
 *
 * Given a resolved [AngelIntent] and the detected [Lang], it returns a natural
 * reply in that same language, filling in live values (time / date / day) using
 * the matching locale so numbers and month names are localized. This is a
 * deterministic, fully-offline layer — swap in an on-device LLM behind the same
 * [reply] signature later without touching callers.
 */
object ReplyEngine {

    fun reply(intent: AngelIntent, lang: Lang, raw: String): Reply {
        val text = when (intent) {
            AngelIntent.GREETING -> pick(
                lang,
                en = "Hello! How can I help you?",
                mr = "नमस्कार! मी आपली काय मदत करू?",
                hi = "नमस्ते! मैं आपकी क्या मदद करूँ?"
            )
            AngelIntent.HOW_ARE_YOU -> pick(
                lang,
                en = "I'm doing great, thanks for asking! How are you?",
                mr = "मी अगदी छान आहे, विचारल्याबद्दल धन्यवाद! तुम्ही कसे आहात?",
                hi = "मैं बिल्कुल ठीक हूँ, पूछने के लिए धन्यवाद! आप कैसे हैं?"
            )
            AngelIntent.IDENTITY -> pick(
                lang,
                en = "I'm Angel, your offline voice assistant. I speak Marathi, Hindi and English.",
                mr = "मी एंजेल, तुमची ऑफलाइन आवाज सहाय्यक. मी मराठी, हिंदी आणि इंग्रजी बोलते.",
                hi = "मैं एंजेल हूँ, आपकी ऑफलाइन वॉइस असिस्टेंट। मैं मराठी, हिंदी और अंग्रेज़ी बोलती हूँ।"
            )
            AngelIntent.TIME -> {
                val t = format("h:mm a", lang)
                pick(lang, en = "It's $t.", mr = "आत्ता $t वाजले आहेत.", hi = "अभी $t बजे हैं।")
            }
            AngelIntent.DATE -> {
                val d = format("d MMMM yyyy", lang)
                pick(lang, en = "Today is $d.", mr = "आजची तारीख $d आहे.", hi = "आज की तारीख $d है।")
            }
            AngelIntent.DAY -> {
                val day = format("EEEE", lang)
                pick(lang, en = "Today is $day.", mr = "आज $day आहे.", hi = "आज $day है।")
            }
            AngelIntent.THANKS -> pick(
                lang,
                en = "You're welcome!",
                mr = "आपले स्वागत आहे!",
                hi = "आपका स्वागत है!"
            )
            AngelIntent.HELP -> pick(
                lang,
                en = "You can ask me the time, the date, to read your messages, who's calling, " +
                    "or to confirm a payment. Say Angel to wake me anytime.",
                mr = "तुम्ही मला वेळ, तारीख, मेसेज वाचायला, कोण कॉल करतंय हे विचारू शकता, " +
                    "किंवा पेमेंट कन्फर्म करायला सांगू शकता. मला उठवायला कधीही एंजेल म्हणा.",
                hi = "आप मुझसे समय, तारीख, मैसेज पढ़ने, कौन कॉल कर रहा है, या पेमेंट कन्फर्म करने " +
                    "को कह सकते हैं। मुझे जगाने के लिए कभी भी एंजेल कहें।"
            )
            AngelIntent.GOODBYE -> pick(
                lang,
                en = "Goodbye! Say Angel whenever you need me.",
                mr = "पुन्हा भेटू! गरज असेल तेव्हा एंजेल म्हणा.",
                hi = "फिर मिलेंगे! ज़रूरत हो तो एंजेल कहें।"
            )
            else -> pick(
                lang,
                en = "Sorry, I didn't catch that. Say 'help' to hear what I can do.",
                mr = "माफ करा, मला नीट समजलं नाही. मी काय करू शकते हे ऐकायला 'मदत' म्हणा.",
                hi = "माफ़ कीजिए, मैं समझ नहीं पाई। मैं क्या कर सकती हूँ सुनने के लिए 'मदद' कहें।"
            )
        }
        return Reply(text, lang)
    }

    private fun pick(lang: Lang, en: String, mr: String, hi: String): String = when (lang) {
        Lang.ENGLISH -> en
        Lang.MARATHI -> mr
        Lang.HINDI -> hi
    }

    private fun format(pattern: String, lang: Lang): String =
        SimpleDateFormat(pattern, lang.locale).format(Date())
}
