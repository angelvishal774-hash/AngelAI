package com.angel.ai.speech

/**
 * A "fresh" rolling buffer of recognized utterances.
 *
 * Each new recognition session starts clean so stale partials from a previous
 * wake window never leak into the next command. Only the most recent [capacity]
 * finalized phrases are retained.
 */
class CommandBuffer(private val capacity: Int = 8) {

    private val entries = ArrayDeque<String>()

    /** Wipe everything — called on each wake so every command starts fresh. */
    @Synchronized
    fun reset() {
        entries.clear()
    }

    @Synchronized
    fun push(phrase: String) {
        val clean = phrase.trim()
        if (clean.isEmpty()) return
        entries.addLast(clean)
        while (entries.size > capacity) entries.removeFirst()
    }

    /** The latest finalized phrase, or null if the buffer is empty. */
    @Synchronized
    fun latest(): String? = entries.lastOrNull()

    @Synchronized
    fun snapshot(): List<String> = entries.toList()
}
