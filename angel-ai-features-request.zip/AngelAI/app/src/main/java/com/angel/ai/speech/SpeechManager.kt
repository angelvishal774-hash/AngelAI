package com.angel.ai.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Continuous SpeechRecognizer wrapper.
 *
 * Android's [SpeechRecognizer] is single-shot, so to fake "always listening" we
 * restart it whenever it ends or errors. Recognition is biased toward Marathi
 * (mr-IN) but falls back to the device default, and partial results are streamed
 * so the wake word can be caught mid-utterance.
 */
class SpeechManager(
    private val context: Context,
    private val onResult: (String, Boolean) -> Unit,
    private val onError: (Int) -> Unit
) {

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var restartOnEnd = false

    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
    }

    fun start() {
        if (listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "Speech recognition unavailable on this device")
            onError(SpeechRecognizer.ERROR_RECOGNIZER_BUSY)
            return
        }
        restartOnEnd = true
        beginSession()
    }

    fun stop() {
        restartOnEnd = false
        listening = false
        recognizer?.apply {
            stopListening()
            cancel()
            destroy()
        }
        recognizer = null
    }

    private fun beginSession() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(sessionListener)
            startListening(intent)
        }
        listening = true
    }

    private fun restart() {
        if (!restartOnEnd) return
        // Small guard against tight error loops.
        recognizer?.destroy()
        recognizer = null
        listening = false
        beginSession()
    }

    private val sessionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onPartialResults(partialResults: Bundle?) {
            firstResult(partialResults)?.let { onResult(it, false) }
        }

        override fun onResults(results: Bundle?) {
            firstResult(results)?.let { onResult(it, true) }
            restart()
        }

        override fun onError(error: Int) {
            // NO_MATCH / SPEECH_TIMEOUT are normal in an always-on loop.
            if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            ) {
                onError(error)
            }
            restart()
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}

        private fun firstResult(bundle: Bundle?): String? =
            bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
    }

    companion object {
        private const val TAG = "AngelSpeech"
    }
}
