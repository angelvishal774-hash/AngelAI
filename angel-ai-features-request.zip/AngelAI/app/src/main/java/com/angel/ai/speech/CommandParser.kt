package com.angel.ai.speech

import java.util.Locale

/** Intents Angel understands, resolved from Marathi / Hindi / English speech. */
enum class AngelIntent {
    WAKE,          // "Angel" / "एंजेल" — start a fresh command window
    SLEEP,         // "Angel stop" / "Angel sleep" / "एंजेल थांब"
    READ_MESSAGES, // read out latest message notification
    CALL_INFO,     // tell who is calling
    CONFIRM_YES,   // approve a gated action (e.g. UPI payment)
    CONFIRM_NO,    // reject a gated action

    // Conversational intents handled by ReplyEngine
    GREETING,      // hello / नमस्कार / नमस्ते
    HOW_ARE_YOU,   // how are you / कसा आहेस / कैसे हो
    IDENTITY,      // who are you / तुझं नाव काय / तुम कौन हो
    TIME,          // what's the time / किती वाजले / कितने बजे
    DATE,          // what's the date / आजची तारीख / आज की तारीख
    DAY,           // which day is it / आज कोणता वार / आज कौन सा दिन
    THANKS,        // thanks / धन्यवाद / शुक्रिया
    HELP,          // what can you do / काय करू शकतेस / क्या कर सकती हो
    GOODBYE,       // bye / येतो / अलविदा

    UNKNOWN
}

data class ParsedCommand(val intent: AngelIntent, val raw: String)

/**
 * Lightweight multilingual keyword matcher. It normalizes case/whitespace and
 * checks Marathi (Devanagari), Hindi (Devanagari) and English phrasings.
 *
 * A keyword-based approach is deliberate: it runs fully offline, is instant, and
 * is easy to extend. Match order matters — more specific intents are tested
 * before generic ones. Swap in an NLU/LLM layer later behind the same interface.
 */
object CommandParser {

    private val wake = listOf("angel", "एंजेल", "एन्जेल", "एंजल", "hey angel", "ok angel")

    private val sleep = listOf(
        "angel stop", "angel sleep", "stop listening", "go to sleep", "sleep",
        "एंजेल थांब", "थांब", "झोप", "बंद कर",            // Marathi
        "एंजेल रुको", "रुको", "बंद करो", "सो जाओ"          // Hindi
    )

    private val greeting = listOf(
        "hello", "hi ", "hey", "good morning", "good evening", "good afternoon",
        "नमस्कार", "शुभ सकाळ", "शुभ प्रभात", "हॅलो",        // Marathi
        "नमस्ते", "नमस्कार जी", "हाय", "सुप्रभात"           // Hindi
    )

    private val howAreYou = listOf(
        "how are you", "how r u", "how are things",
        "कसा आहेस", "कशी आहेस", "कसे आहात", "कसं चाललंय",   // Marathi
        "कैसे हो", "कैसे हैं", "कैसी हो", "क्या हाल"         // Hindi
    )

    private val identity = listOf(
        "who are you", "what is your name", "your name", "who made you",
        "तुझं नाव", "तुझे नाव", "तुमचं नाव", "कोण आहेस",     // Marathi
        "तुम्हारा नाम", "तुम कौन", "आप कौन", "तेरा नाम"      // Hindi
    )

    private val time = listOf(
        "time", "what time", "clock",
        "किती वाजले", "वेळ काय", "वेळ सांग",               // Marathi
        "कितने बजे", "समय क्या", "टाइम क्या"               // Hindi
    )

    private val date = listOf(
        "date", "what date", "today's date",
        "आजची तारीख", "तारीख काय", "तारीख सांग",           // Marathi
        "आज की तारीख", "तारीख क्या", "डेट क्या"            // Hindi
    )

    private val day = listOf(
        "which day", "what day", "day today",
        "कोणता वार", "आज कोणता दिवस", "वार कोणता",          // Marathi
        "कौन सा दिन", "आज कौन दिन", "दिन कौन"               // Hindi
    )

    private val thanks = listOf(
        "thanks", "thank you", "thank u",
        "धन्यवाद", "आभारी", "आभार",                        // Marathi
        "शुक्रिया", "धन्यवाद जी", "बहुत धन्यवाद"            // Hindi
    )

    private val help = listOf(
        "help", "what can you do", "what do you do", "commands",
        "मदत", "काय करू शकतेस", "काय करतेस",               // Marathi
        "मदद", "क्या कर सकती हो", "क्या करती हो"            // Hindi
    )

    private val goodbye = listOf(
        "bye", "goodbye", "see you", "see ya", "good night",
        "येतो", "निघतो", "पुन्हा भेटू", "शुभ रात्री",        // Marathi
        "अलविदा", "फिर मिलेंगे", "टाटा", "शुभ रात्रि"        // Hindi
    )

    private val readMessages = listOf(
        "read message", "read messages", "any messages", "new message",
        "मेसेज वाच", "संदेश वाच", "मेसेज वाचून दाखव",        // Marathi
        "मैसेज पढ़ो", "संदेश पढ़ो", "मैसेज सुनाओ"            // Hindi
    )

    private val callInfo = listOf(
        "who is calling", "who called", "whose call",
        "कोण कॉल करतंय", "कोणाचा फोन", "कॉल कोणाचा",        // Marathi
        "कौन कॉल कर रहा है", "किसका फोन", "कौन बुला रहा"     // Hindi
    )

    private val yes = listOf(
        "yes", "confirm", "approve", "go ahead", "allow", "pay",
        "हो", "होय", "पाठव", "कर",                          // Marathi
        "हाँ", "हां", "करो", "भेजो", "मंज़ूर"               // Hindi
    )

    private val no = listOf(
        "no", "cancel", "reject", "don't", "do not", "block",
        "नको", "नाही", "रद्द",                              // Marathi
        "नहीं", "मत", "रद्द करो", "रोको"                    // Hindi
    )

    fun parse(rawInput: String): ParsedCommand {
        val text = rawInput.lowercase(Locale.ROOT).trim()
        val intent = when {
            sleep.anyIn(text) -> AngelIntent.SLEEP
            goodbye.anyIn(text) -> AngelIntent.GOODBYE
            thanks.anyIn(text) -> AngelIntent.THANKS
            help.anyIn(text) -> AngelIntent.HELP
            howAreYou.anyIn(text) -> AngelIntent.HOW_ARE_YOU
            identity.anyIn(text) -> AngelIntent.IDENTITY
            time.anyIn(text) -> AngelIntent.TIME
            date.anyIn(text) -> AngelIntent.DATE
            day.anyIn(text) -> AngelIntent.DAY
            readMessages.anyIn(text) -> AngelIntent.READ_MESSAGES
            callInfo.anyIn(text) -> AngelIntent.CALL_INFO
            greeting.anyIn(text) -> AngelIntent.GREETING
            yes.anyIn(text) -> AngelIntent.CONFIRM_YES
            no.anyIn(text) -> AngelIntent.CONFIRM_NO
            wake.anyIn(text) -> AngelIntent.WAKE
            else -> AngelIntent.UNKNOWN
        }
        return ParsedCommand(intent, rawInput.trim())
    }

    /** True if the utterance contains the wake word anywhere. */
    fun containsWake(rawInput: String): Boolean =
        wake.anyIn(rawInput.lowercase(Locale.ROOT))

    private fun List<String>.anyIn(text: String): Boolean =
        any { kw -> text == kw || text.contains(kw) }
}
