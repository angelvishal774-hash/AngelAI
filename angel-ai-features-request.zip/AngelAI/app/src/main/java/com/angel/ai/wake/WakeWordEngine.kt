package com.angel.ai.wake

/**
 * A microphone-owning offline wake-word detector.
 *
 * Implementations run entirely on-device and continuously listen for the wake
 * word ("Angel"). Because Android only lets one component capture the mic at a
 * time, the service starts an engine while SLEEPING and stops it before handing
 * the mic to [android.speech.SpeechRecognizer] while AWAKE.
 */
interface WakeWordEngine {

    /** Stable id for logging / diagnostics. */
    val id: String

    /**
     * True when this engine actually captures the microphone itself. The
     * [NoOpWakeWordEngine] returns false, signalling the service to fall back to
     * SpeechRecognizer-based wake detection.
     */
    val ownsMicrophone: Boolean

    /** Begin listening for the wake word. Safe to call when already started. */
    fun start()

    /** Release the microphone and any native resources. */
    fun stop()
}

/** Placeholder used when no offline model/asset is available on the device. */
class NoOpWakeWordEngine : WakeWordEngine {
    override val id = "speechrecognizer-fallback"
    override val ownsMicrophone = false
    override fun start() {}
    override fun stop() {}
}
