package com.angel.ai.upi

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.angel.ai.service.AngelForegroundService

/**
 * Watches UPI apps (PhonePe, Google Pay, Paytm, BHIM, ...) and gates the moment
 * a "Pay" / payment-confirmation screen appears.
 *
 * IMPORTANT / HONEST LIMITATION: stock Android does not let one app cancel a
 * transaction inside another app. What this service *can* do is:
 *   1. Detect the payment screen via accessibility events + text matching.
 *   2. Immediately raise Angel's confirmation gate (a full-screen overlay) so
 *      the user must say / tap "yes" before proceeding.
 *   3. On rejection, navigate the UPI app BACK (GLOBAL_ACTION_BACK), which backs
 *      out of the payment screen — the closest sanctioned "block".
 *
 * This is a friction/confirmation layer, not a hard OS-level payment firewall.
 */
class UpiGuardAccessibilityService : AccessibilityService() {

    private var lastGatedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in UPI_PACKAGES) return

        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return

        val root = rootInActiveWindow ?: return
        if (!looksLikePayment(root)) return

        // Debounce: don't re-gate the same screen repeatedly.
        val now = System.currentTimeMillis()
        if (now - lastGatedAt < GATE_DEBOUNCE_MS) return
        lastGatedAt = now

        val payee = extractPayee(root) ?: appLabel(pkg)
        Log.i(TAG, "UPI payment screen detected in $pkg (payee=$payee)")

        // Notify the voice brain so it can announce & listen for yes/no.
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(AngelForegroundService.EVENT_UPI_DETECTED)
                .putExtra(AngelForegroundService.EXTRA_TEXT, payee)
        )

        // Raise the confirmation overlay on top of the UPI app.
        startActivity(
            Intent(this, UpiConfirmActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(UpiConfirmActivity.EXTRA_PAYEE, payee)
                .putExtra(UpiConfirmActivity.EXTRA_PACKAGE, pkg)
        )
    }

    override fun onInterrupt() {}

    /** Called by [UpiConfirmActivity] via a static hook to back out of a payment. */
    fun blockCurrentPayment() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "UPI guard connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    private fun looksLikePayment(root: AccessibilityNodeInfo): Boolean {
        for (kw in PAY_KEYWORDS) {
            val hits = root.findAccessibilityNodeInfosByText(kw)
            if (!hits.isNullOrEmpty()) return true
        }
        return false
    }

    private fun extractPayee(root: AccessibilityNodeInfo): String? {
        for (kw in PAYEE_HINTS) {
            val hits = root.findAccessibilityNodeInfosByText(kw) ?: continue
            for (n in hits) {
                val t = n.text?.toString().orEmpty()
                if (t.isNotBlank() && t.length < 40) return t
            }
        }
        return null
    }

    private fun appLabel(pkg: String): String = when (pkg) {
        "com.phonepe.app" -> "PhonePe"
        "com.google.android.apps.nbu.paisa.user" -> "Google Pay"
        "net.one97.paytm" -> "Paytm"
        "in.org.npci.upiapp" -> "BHIM"
        else -> "UPI"
    }

    companion object {
        private const val TAG = "AngelUpiGuard"
        private const val GATE_DEBOUNCE_MS = 4_000L

        @Volatile
        var instance: UpiGuardAccessibilityService? = null
            private set

        val UPI_PACKAGES = setOf(
            "com.phonepe.app",
            "com.google.android.apps.nbu.paisa.user",
            "net.one97.paytm",
            "in.org.npci.upiapp",
            "in.amazon.mShop.android.shopping"
        )

        private val PAY_KEYWORDS = listOf(
            "Pay ₹", "Proceed to Pay", "Send", "Pay Securely", "Confirm Payment",
            "Swipe to pay", "Enter UPI PIN", "पैसे भेजें", "भुगतान करें", "पैसे पाठवा"
        )

        private val PAYEE_HINTS = listOf(
            "To ", "Paying to", "Payee", "@ok", "@ybl", "@paytm", "@axl"
        )
    }
}
