package com.angel.ai.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/**
 * Wraps Android TextToSpeech for Angel's spoken responses.
 *
 * On init it picks a sane default (Marathi → Hindi → English by availability).
 * Each [speak] call may request a specific locale so replies are voiced in the
 * same language the user spoke; if that voice isn't installed it gracefully
 * falls back down the preference chain.
 */
class TtsManager(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var currentLocale: Locale? = null

    private val preferred = listOf(
        Locale("mr", "IN"), // Marathi
        Locale("hi", "IN"), // Hindi
        Locale.ENGLISH
    )

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            Log.w(TAG, "TTS init failed: $status")
            return
        }
        applyBestAvailable(preferred)
        ready = true
    }

    /** Speak text (flushing the queue), optionally in a specific [locale]. */
    fun speak(text: String, locale: Locale? = null) {
        if (!ready || text.isBlank()) return
        if (locale != null) applyLocale(locale)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "angel-${System.currentTimeMillis()}")
    }

    private fun applyLocale(locale: Locale) {
        if (locale == currentLocale) return
        val res = tts.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Requested voice unavailable — fall back through the preference chain.
            applyBestAvailable(listOf(locale) + preferred)
        } else {
            currentLocale = locale
        }
    }

    private fun applyBestAvailable(candidates: List<Locale>) {
        for (loc in candidates) {
            val res = tts.setLanguage(loc)
            if (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED) {
                currentLocale = loc
                Log.i(TAG, "TTS language set to $loc")
                return
            }
        }
        Log.w(TAG, "No preferred TTS language available")
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    companion object {
        private const val TAG = "AngelTts"
    }
}
