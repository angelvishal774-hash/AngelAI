package com.angel.ai

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.angel.ai.service.AngelForegroundService

/**
 * Control panel: requests the permissions Angel needs, starts/stops the brain,
 * and shows live state + last transcript. All the heavy lifting lives in the
 * services; this is a thin dashboard.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var stateText: TextView
    private lateinit var transcriptText: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* state reflected in the UI regardless */ refreshPermissionHints() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stateText = findViewById(R.id.stateText)
        transcriptText = findViewById(R.id.transcriptText)

        findViewById<Button>(R.id.startBtn).setOnClickListener {
            ensurePermissions()
            AngelForegroundService.start(this)
        }
        findViewById<Button>(R.id.wakeBtn).setOnClickListener {
            send(AngelForegroundService.ACTION_WAKE)
        }
        findViewById<Button>(R.id.sleepBtn).setOnClickListener {
            send(AngelForegroundService.ACTION_SLEEP)
        }
        findViewById<Button>(R.id.notifAccessBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.accessibilityBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.overlayBtn).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !Settings.canDrawOverlays(this)
            ) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }

    private fun send(action: String) {
        startService(Intent(this, AngelForegroundService::class.java).setAction(action))
    }

    private fun ensurePermissions() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        val toAsk = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toAsk.isNotEmpty()) permissionLauncher.launch(toAsk.toTypedArray())
    }

    private fun refreshPermissionHints() { /* hook for future UI badges */ }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                AngelForegroundService.EVENT_STATE ->
                    stateText.text = getString(
                        R.string.state_label,
                        intent.getStringExtra(AngelForegroundService.EXTRA_STATE)
                    )
                AngelForegroundService.EVENT_TRANSCRIPT ->
                    transcriptText.text = intent.getStringExtra(AngelForegroundService.EXTRA_TEXT)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(AngelForegroundService.EVENT_STATE)
            addAction(AngelForegroundService.EVENT_TRANSCRIPT)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter)
    }

    override fun onStop() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver)
        super.onStop()
    }
}
