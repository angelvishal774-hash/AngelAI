package com.angel.ai.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts Angel's foreground service after a reboot. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            AngelForegroundService.start(context)
        }
    }
}
