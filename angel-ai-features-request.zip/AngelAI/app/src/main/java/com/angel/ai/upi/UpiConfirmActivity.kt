package com.angel.ai.upi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.angel.ai.R
import com.angel.ai.service.AngelForegroundService

/**
 * Full-screen confirmation gate shown over a UPI app when a payment screen is
 * detected. The user approves/blocks either by tapping or by voice — the voice
 * decision arrives as a LocalBroadcast from [AngelForegroundService].
 */
class UpiConfirmActivity : AppCompatActivity() {

    private val autoBlock = Handler(Looper.getMainLooper())
    private var decided = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upi_confirm)

        val payee = intent.getStringExtra(EXTRA_PAYEE) ?: "?"
        findViewById<TextView>(R.id.payeeText).text =
            getString(R.string.confirm_payment, payee)

        findViewById<Button>(R.id.approveBtn).setOnClickListener { decide(true) }
        findViewById<Button>(R.id.blockBtn).setOnClickListener { decide(false) }

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(voiceReceiver, IntentFilter(AngelForegroundService.EVENT_UPI_DECISION))

        // Safety default: if no decision is made, block after the timeout.
        autoBlock.postDelayed({ if (!decided) decide(false) }, AUTO_BLOCK_MS)
    }

    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val approved = intent?.getBooleanExtra(AngelForegroundService.EXTRA_APPROVED, false) ?: false
            decide(approved)
        }
    }

    private fun decide(approved: Boolean) {
        if (decided) return
        decided = true
        autoBlock.removeCallbacksAndMessages(null)
        if (!approved) {
            // Back out of the UPI app's payment screen.
            UpiGuardAccessibilityService.instance?.blockCurrentPayment()
        }
        finish()
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(voiceReceiver)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PAYEE = "payee"
        const val EXTRA_PACKAGE = "package"
        private const val AUTO_BLOCK_MS = 15_000L
    }
}
