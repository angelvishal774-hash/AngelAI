package com.angel.ai.notify

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.angel.ai.service.AngelForegroundService

/**
 * Reads incoming call & message notifications and relays a short summary to the
 * foreground service so Angel can announce them by voice.
 *
 * Requires the user to grant "Notification access" in system settings.
 */
class AngelNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return
        val extras = sbn.notification?.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        when {
            isCall(pkg, sbn.notification) -> relay(AngelForegroundService.EVENT_CALL, title.ifBlank { text })
            isMessage(pkg) -> relay(AngelForegroundService.EVENT_MESSAGE, buildMessage(title, text))
        }
    }

    private fun isCall(pkg: String, n: Notification?): Boolean {
        if (n?.category == Notification.CATEGORY_CALL) return true
        return pkg in CALL_PACKAGES
    }

    private fun isMessage(pkg: String): Boolean = pkg in MESSAGE_PACKAGES

    private fun buildMessage(title: String, text: String): String =
        listOf(title, text).filter { it.isNotBlank() }.joinToString(": ")

    private fun relay(action: String, payload: String) {
        if (payload.isBlank()) return
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(action).putExtra(AngelForegroundService.EXTRA_TEXT, payload)
        )
    }

    companion object {
        private val CALL_PACKAGES = setOf(
            "com.android.server.telecom",
            "com.google.android.dialer",
            "com.samsung.android.incallui",
            "com.whatsapp",
            "org.telegram.messenger"
        )
        private val MESSAGE_PACKAGES = setOf(
            "com.google.android.apps.messaging",
            "com.whatsapp",
            "org.telegram.messenger",
            "com.samsung.android.messaging"
        )
    }
}
